function [  ] = Pic( State_ball )
%����С��ĵ���·��ͼ

n = length(State_ball);
%���Ƶ�ͼ
theta = linspace(0,2*pi,100);
x = 0.2*cos(theta);
y = 0.2*sin(theta);
plot(x,y,'b');
xlim([-0.3,0.3]);
ylim([-0.3,0.3]);

hold on
for i=1:n-1
    O = State_ball(i).O;
    O_ = State_ball(i+1).O;
    plot([O(1),O_(1)],[O(2),O_(2)],'b--');
    scatter(O(1),O(2),'r.');    
end
scatter(O_(1),O_(2),'r.');

end

