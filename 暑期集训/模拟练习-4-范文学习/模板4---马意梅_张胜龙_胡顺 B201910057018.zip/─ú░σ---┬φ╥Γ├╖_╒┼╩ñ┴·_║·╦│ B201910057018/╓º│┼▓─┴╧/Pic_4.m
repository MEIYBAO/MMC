function [  ] = Pic_4( O )
%��������4����µĹ��ƶ�ͼ

%���Ƶ�ͼ
theta = linspace(0,2*pi,100);
x1 = 0.2*cos(theta);
y1 = 0.2*sin(theta);
x2 = 0.2*cos(theta)+0.0205;
y2 = 0.2*sin(theta)+0.0044;
plot(x1,y1);
hold on 
plot(x2,y2);

hold on
for i=1:2
    plot([O(i,1),O(i+1,1)],[O(i,2),O(i+1,2)],'b--');
    scatter(O(i,1),O(i,2),'r.');    
end
scatter(O(3,1),O(3,2),'r.')
end

